"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var credit_note_component_1 = require("../credit-note/credit-note.component");
credit_note_component_1.Component({
    templateUrl: 'credit-note.component.html',
});
var CreditNoteComponent = /** @class */ (function () {
    function CreditNoteComponent() {
    }
    CreditNoteComponent.prototype.ngOninit = function () { };
    return CreditNoteComponent;
}());
exports.CreditNoteComponent = CreditNoteComponent;
