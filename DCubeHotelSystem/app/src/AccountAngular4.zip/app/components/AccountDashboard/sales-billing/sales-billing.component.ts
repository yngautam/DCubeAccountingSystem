﻿import { Component, OnInit, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgModel, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { AccountTransactionValues, AccountTrans, PurchaseOrderDetail, ScreenOrderDetail, EntityMock } from '../../../Model/AccountTransaction/accountTrans';
import { Account } from '../../../Model/Account/account';
import { PurchaseService } from '../../../Service/purchase.service';
import { PurchaseDetailsService } from '../../../Service/PurchaseDetails.service';
import { AccountTransValuesService } from '../../../Service/accountTransValues.service';
import { DBOperation } from '../../../Shared/enum';
import { Observable } from 'rxjs/Rx';
import { Global } from '../../../Shared/global';
import { DatePipe } from '@angular/common'
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as XLSX from 'xlsx';
import { FileService } from '../../../Service/file.service';
import { ReservationCustomerService } from '../../../Service/customer.services';
import { MenuItemPortion } from '../../../Model/Menu/MenuItemPortion';
import { IMenuItemPortion, IMenuItem } from '../../../Model/Menu/MenuItem';
import { MenuConsumptionService } from '../../../Service/MenuConsumptionService';
type CSV = any[][];

@Component({
    templateUrl: './sales-billing.component.html',
    styleUrls: ['./sales-billing.component.css']
})
export class SalesBillingComponent implements OnInit {
    @ViewChild("template") TemplateRef: TemplateRef<any>;
    @ViewChild('templateNested') TemplateRef2: TemplateRef<any>;
    @ViewChild('fileInput') fileInput: ElementRef;
    public MenuItem: IMenuItemPortion;

    IsDiscountPercentage: boolean;
    selectedValue: any = '0.00';
    modalRef: BsModalRef;
    modalRef2: BsModalRef;
    public salesBillingForm: FormGroup;
    SalesBilling: AccountTrans[];

    dbops: DBOperation;
    msg: string;
    modalTitle: string;
    modalBtnTitle: string;
    indLoading: boolean = false;
    private formSubmitAttempt: boolean;
    private buttonDisabled: boolean;
    formattedDate: any;
    public entityLists: EntityMock[];
    public fromDate: any;
    public toDate: any;
    public sfromDate: string;
    public stoDate: string;
    public currentYear: any = {};
    public currentUser: any = {};
    public company: any = {};
    dropMessage: string = "Upload Reference File";
    toExportFileName: string = 'Sales Voucher of ' + this.date.transform(new Date, "dd-MM-yyyy") + '.xls';
    uploadUrl = Global.BASE_FILE_UPLOAD_ENDPOINT;
    fileUrl: string = '';
    settings = {
        bigBanner: false,
        timePicker: false,
        format: 'dd/MM/yyyy',
        defaultOpen: false
    };

    public SourceAccountTypeId: string;
    public currentaccount: Account;
    public vdate: string;
    public currentvdate: string;
    public CustomerAccounts: Observable<Account>;
    public currentItem: string;
    public imenuitemPortion: Observable<IMenuItemPortion>;
    MenuItemPortions: Observable<MenuItemPortion>;

    /**
     * Constructor
     * 
     * @param fb 
     * @param _purchaseService 
     * @param _purchaseDetailsService 
     * @param _accountTransValues 
     * @param date 
     * @param modalService 
     */
    constructor(
        private fb: FormBuilder,
        private _purchaseService: PurchaseService,
        private _purchaseDetailsService: PurchaseDetailsService,
        private _accountTransValues: AccountTransValuesService,
        private _customerService: ReservationCustomerService,
        private date: DatePipe,
        private modalService: BsModalService,
        private fileService: FileService,
        private _menuConsumptionService: MenuConsumptionService,
    ) {
        this._menuConsumptionService.getMenuConsumptionProductPortions().subscribe(data => this.MenuItemPortions = data);
        this.currentYear = JSON.parse(localStorage.getItem('currentYear'));
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.company = JSON.parse(localStorage.getItem('company'));
        this.fromDate = this.currentYear['NepaliStartDate'];
        this.toDate = this.currentYear['NepaliEndDate'];
    }

    ngOnInit(): void {
        this.salesBillingForm = this.fb.group({
            Id: [''],
            Name: [''],
            AccountTransactionDocumentId: [''],
            Date: ['', Validators.compose([Validators.required, this.nepaliDateValidator])],
            SourceAccountTypeId: ['', Validators.required],
            Description: ['', Validators.required],
            Amount: [''],
            PercentAmount: [''],
            NetAmount: [''],
            Discount: [''], 
            GrandAmount: [''],
            FinancialYear: [''],
            UserName: [''],
            CompanyCode: [''],
            IsDiscountPercentage: [''], 
            SalesOrderDetails: this.fb.array([this.initSalesOrderDetails()])
        });
        this.loadSalesBillingList(this.fromDate, this.toDate);
    }

    voucherDateValidator(currentdate: string) {
        if (currentdate == "") {
            alert("Please enter the voucher date");
            return false;
        }
        let today = new Date;
        this._purchaseService.get(Global.BASE_NEPALIMONTH_ENDPOINT + '?NDate=' + currentdate)
            .subscribe(SB => {
                this.vdate = SB;
            },
                error => this.msg = <any>error);
        if (this.vdate === "undefined") {
            alert("Please enter the voucher valid date");
            return false;
        }
        let voucherDate = new Date(this.vdate);

        let tomorrow = new Date(today.setDate(today.getDate() + 1));

        let currentYearStartDate = new Date(this.currentYear.StartDate);
        let currentYearEndDate = new Date(this.currentYear.EndDate);

        if ((voucherDate < currentYearStartDate) || (voucherDate > currentYearEndDate) || voucherDate >= tomorrow) {
            alert("Date should be within current financial year's start date and end date inclusive");
            return false;
        }
        else {
            return true;
        }
    }


    viewFile(fileUrl, template: TemplateRef<any>) {
        this.fileUrl = fileUrl;
        this.modalTitle = "View Attachment";
        this.modalRef = this.modalService.show(template, { keyboard: false, class: 'modal-lg' });
    }

    /**
     * Exports the pOrder voucher data in CSV/ Excel format
     */
    exportTableToExcel(tableID, filename = '') {
        var downloadLink;
        var dataType = 'application/vnd.ms-excel';
        var clonedtable = $('#' + tableID);
        var clonedHtml = clonedtable.clone();
        $(clonedtable).find('.export-no-display').remove();
        var tableSelect = document.getElementById(tableID);
        var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
        $('#' + tableID).html(clonedHtml.html());

        // Specify file name
        filename = filename ? filename + '.xls' : this.toExportFileName;

        // Create download link element
        downloadLink = document.createElement("a");

        document.body.appendChild(downloadLink);

        if (navigator.msSaveOrOpenBlob) {
            var blob = new Blob(['\ufeff', tableHTML], { type: dataType });
            navigator.msSaveOrOpenBlob(blob, filename);
        } else {
            // Create a link to the file
            downloadLink.href = 'data:' + dataType + ', ' + tableHTML;

            // Setting the file name
            downloadLink.download = filename;

            //triggering the function
            downloadLink.click();
        }
    }

    loadSalesBillingList(sfromdate: string, stodate: string){
        this.indLoading = true;
        if (sfromdate == "undefined" || sfromdate == null) {
            alert("Enter Start Date");
            return false;
        }
        if (stodate == "undefined" || stodate == null) {
            alert("Enter End Date");
            return false;
        }
        if (this.nepaliDateStringValidator(stodate) === false) {
            alert("Enter Valid End Date");
            return false;
        }
        if (this.nepaliDateStringValidator(sfromdate) === false) {
            alert("Enter Valid Start Date");
            return false;
        }

        this.fromDate = sfromdate;
        this.toDate = stodate;
        this.sfromDate = sfromdate;
        this.stoDate = stodate;
        this.indLoading = true;

        this._purchaseService.get(Global.BASE_ACCOUNT_ENDPOINT + '?AccountTypeId=AT&AccountGeneral=AG&CustomerId=CI')
            .subscribe(at => {
                this.CustomerAccounts = at;
            },
                error => this.msg = <any>error);

        this._purchaseService.get(Global.BASE_SALE_BILLING_ENDPOINT + '?fromDate=' + this.fromDate + '&toDate=' + this.toDate + '&TransactionTypeId=' + 3)
            .subscribe(
            SalesBilling => {
                SalesBilling.map((purch) => purch['File'] = Global.BASE_HOST_ENDPOINT + Global.BASE_FILE_UPLOAD_ENDPOINT + '?Id=' + purch.Id + '&ApplicationModule=JournalVoucher');
                this.SalesBilling = SalesBilling;
                this.indLoading = false;
            },
            error => this.msg = <any>error
            );
    }

    addSalesBilling() {
        this.dbops = DBOperation.create;
        this.SetControlsState(true);
        this.modalTitle = "Add Sales Billing";
        this.modalBtnTitle = "Save";
        this.reset();
        this.salesBillingForm.controls['Name'].setValue('Direct Sales');
        this.modalRef = this.modalService.show(this.TemplateRef, {
            backdrop: 'static',
            keyboard: false,
            class: 'modal-lg'
        });
    }

    getSalesBilling(Id: number) {
        this.indLoading = true;
        return this._purchaseService.get(Global.BASE_SALE_BILLING_ENDPOINT + '?TransactionId=' + Id);
    }

    /**
     * Opens Edit Existing Journal Voucher Form Modal
     * @param Id 
     */
    editSalesBilling(Id: number) {
        this.reset();
        this.dbops = DBOperation.update;
        this.SetControlsState(true);
        this.modalTitle = "Edit Sales Billing";
        this.modalBtnTitle = "Update";
        this.getSalesBilling(Id)
            .subscribe((SalesBilling: AccountTrans) => {
                debugger
                this.indLoading = false;
                this.salesBillingForm.controls['Id'].setValue(SalesBilling.Id);
                this.salesBillingForm.controls['Date'].setValue(SalesBilling.AccountTransactionValues[0]['NVDate']);
                this.salesBillingForm.controls['Name'].setValue(SalesBilling.Name);
                this.salesBillingForm.controls['AccountTransactionDocumentId'].setValue(SalesBilling.AccountTransactionDocumentId);
                this.currentaccount = this.CustomerAccounts.filter(x => x.Id === SalesBilling.SourceAccountTypeId)[0];
                if (this.currentaccount !== undefined) {
                    this.salesBillingForm.controls['SourceAccountTypeId'].setValue(this.currentaccount.Name);
                }
                this.salesBillingForm.controls['Description'].setValue(SalesBilling.Description);
                this.salesBillingForm.controls['Discount'].setValue(SalesBilling.Discount);
                this.salesBillingForm.controls['NetAmount'].setValue(SalesBilling.NetAmount);
                this.salesBillingForm.controls['Amount'].setValue(SalesBilling.Discount + SalesBilling.NetAmount );
                this.salesBillingForm.controls['PercentAmount'].setValue(SalesBilling.PercentAmount);
                this.salesBillingForm.controls['GrandAmount'].setValue(SalesBilling.VATAmount + SalesBilling.NetAmount );

                this.salesBillingForm.controls['SalesOrderDetails'] = this.fb.array([]);
                const control = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'];

                for (let i = 0; i < SalesBilling.SalesOrderDetails.length; i++) {
                    let valuesFromServer = SalesBilling.SalesOrderDetails[i];
                    let instance = this.fb.group(valuesFromServer);
                    this.currentItem = this.MenuItemPortions.filter(x => x.Id === SalesBilling.SalesOrderDetails[i]["ItemId"])[0];
                    if (this.currentaccount !== undefined) {
                        instance.controls["ItemId"].setValue(this.currentItem);
                    }
                    control.push(instance);
                }

                this.modalRef = this.modalService.show(this.TemplateRef, {
                    backdrop: 'static',
                    keyboard: false,
                    class: 'modal-lg'
                });
            });
    }

    deleteSalesBilling(Id: number) {
        this.dbops = DBOperation.delete;
        this.SetControlsState(true);
        this.modalTitle = "Delete Sales Items";
        this.modalBtnTitle = "Delete";
        this.reset();
        this.getSalesBilling(Id)
            .subscribe((SalesBilling: AccountTrans) => {
                debugger
                this.indLoading = false;
                this.salesBillingForm.controls['Id'].setValue(SalesBilling.Id);
                this.salesBillingForm.controls['Date'].setValue(new Date(SalesBilling.Date));
                this.salesBillingForm.controls['Name'].setValue(SalesBilling.Name);
                this.salesBillingForm.controls['AccountTransactionDocumentId'].setValue(SalesBilling.AccountTransactionDocumentId);
                this.currentaccount = this.CustomerAccounts.filter(x => x.Id === SalesBilling.SourceAccountTypeId)[0];
                if (this.currentaccount !== undefined) {
                    this.salesBillingForm.controls['SourceAccountTypeId'].setValue(this.currentaccount.Name);
                }
                this.salesBillingForm.controls['Description'].setValue(SalesBilling.Description);
                this.salesBillingForm.controls['Discount'].setValue(SalesBilling.Discount);
                this.salesBillingForm.controls['Amount'].setValue(SalesBilling.Discount + SalesBilling.NetAmount);
                this.salesBillingForm.controls['NetAmount'].setValue(SalesBilling.NetAmount);
                this.salesBillingForm.controls['PercentAmount'].setValue(SalesBilling.PercentAmount);
                this.salesBillingForm.controls['GrandAmount'].setValue(SalesBilling.VATAmount + SalesBilling.NetAmount);

                this.salesBillingForm.controls['SalesOrderDetails'] = this.fb.array([]);
                const control = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'];

                for (let i = 0; i < SalesBilling.SalesOrderDetails.length; i++) {
                    let valuesFromServer = SalesBilling.SalesOrderDetails[i];
                    let instance = this.fb.group(valuesFromServer);
                    this.currentItem = this.MenuItemPortions.filter(x => x.Id === SalesBilling.SalesOrderDetails[i]["ItemId"])[0];
                    if (this.currentaccount !== undefined) {
                        instance.controls["ItemId"].setValue(this.currentItem);
                    }
                    control.push(instance);
                }

                this.modalRef = this.modalService.show(this.TemplateRef, {
                    backdrop: 'static',
                    keyboard: false,
                    class: 'modal-lg'
                });
            });
    }

    // Initialize the formb uilder arrays
    initSalesOrderDetails() {
        return this.fb.group({
            Id: [''],
            IsSelected: '',
            IsVoid: '',
            ItemId: ['', Validators.required],
            OrderId: '',
            OrderNumber: '',
            Qty: ['', Validators.required],
            Tags: '',
            UnitPrice: ['', Validators.required],
            TotalAmount: [''],
        });
    }

    initJournalDetail() {
        return this.fb.group({
            entityLists: ['', Validators.required],
            AccountId: ['', Validators.required],
            Debit: ['', Validators.required],
            Credit: ['', Validators.required],
            Description: [''],
        });
    }

    // Push the values of purchasdetails
    addSalesBillingitems() {
        const control = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'];
        const addPurchaseValues = this.initSalesOrderDetails();
        control.push(addPurchaseValues);
    }

    //remove the rows//
    removeSalesBillingitems(i: number) {
        let controls = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'];
        let controlToRemove = this.salesBillingForm.controls.SalesOrderDetails['controls'][i].controls;
        let selectedControl = controlToRemove.hasOwnProperty('Id') ? controlToRemove.Id.value : 0;

        if (selectedControl) {
            this._purchaseDetailsService.delete(Global.BASE_SALE_BILLING_DETAILS_ENDPOINT, controlToRemove.Id.value).subscribe(data => {
                alert("Data With Id= " + controlToRemove.Id.value + " Removed Successfully!");
                (data == 1) && controls.removeAt(i);
            });
        } else {
            if (i >= 0) {
                controls.removeAt(i);
            } else {
                alert("Form requires at least one row");
            }
        }
    }

    calculateAmount() {
        let controls = this.salesBillingForm.controls['SalesOrderDetails'].value;
        return controls.reduce(function (total: any, accounts: any) {
            return (accounts.TotalAmount) ? (total + Math.round(accounts.TotalAmount)) : total;
        }, 0);
    }

    calculateNetAmount(salesBillingForm: any) {
        this.getDiscountPercent(salesBillingForm);
        let totalAmt = this.calculateAmount();
        let calcNetAmount = salesBillingForm.NetAmount.setValue((totalAmt - (salesBillingForm.Discount.value)).toFixed(2));
        return calcNetAmount;
    }

    calculateVATAmount(salesBillingForm: any) {
        this.getDiscountPercent(salesBillingForm);
        let totalAmt = this.calculateAmount();
        let calcVatAmt = salesBillingForm.VATAmount.setValue(((totalAmt - (salesBillingForm.Discount.value)) * 0.13).toFixed(2));
        return calcVatAmt;
    }

    calculateGndAmount(salesBillingForm: any) {
        this.getDiscountPercent(salesBillingForm);
        let totalAmt = this.calculateAmount();
        const Discount = (<FormControl>this.salesBillingForm.controls['Discount']);
        const IsDiscountPercentage = (<FormControl>this.salesBillingForm.controls['IsDiscountPercentage']);
        const PercentAmount = (<FormControl>this.salesBillingForm.controls['PercentAmount']);
        let calcGrandTot = 0;
        if (IsDiscountPercentage.value == true) {
            calcGrandTot = salesBillingForm.GrandAmount.setValue(((totalAmt - (((Discount.value / 100) * totalAmt)))).toFixed(2));
        }
        else {
            calcGrandTot = salesBillingForm.GrandAmount.setValue(((totalAmt - (salesBillingForm.Discount.value))).toFixed(2));
        }
        //console.log(calcGrandTot);
        return calcGrandTot;
    }

    calculatePercentDiscountAmount(salesBillingForm: any) {
        const IsDiscountPercentage = (<FormControl>this.salesBillingForm.controls['IsDiscountPercentage']);
        if (salesBillingForm.Discount.value <= this.calculateAmount() && IsDiscountPercentage.value == false) {
            let totalAmt = this.calculateAmount();
            let calcNetAmount = salesBillingForm.NetAmount.setValue(totalAmt - (salesBillingForm.Discount.value));
            let calcGrandTot = salesBillingForm.GrandAmount.setValue((totalAmt - (salesBillingForm.Discount.value)));
            return ((calcNetAmount) & (calcGrandTot)).toFixed(2);
        }
        else {
            alert("Entered value is greater than total amount ? " + "Your entered value is = " + salesBillingForm.Discount.value);
            return false;
        }
    }

    //Calculate discount for more than 0% or less than 100%
    getDiscountPercent(salesBillingForm) {
        const IsDiscountPercentage = (<FormControl>this.salesBillingForm.controls['IsDiscountPercentage']);

        const Discount = (<FormControl>this.salesBillingForm.controls['Discount']);
        const PercentAmount = (<FormControl>this.salesBillingForm.controls['PercentAmount']);
        const NetAmount = (<FormControl>this.salesBillingForm.controls['NetAmount']);
        const GrandAmount = (<FormControl>this.salesBillingForm.controls['GrandAmount']);

        if (Discount.value > 0 && Discount.value <= 100 && IsDiscountPercentage.value == true) {
            let totalAmt = this.calculateAmount();
            let calcPercentAmount = ((Discount.value / 100) * totalAmt).toFixed(2);
            let calcNetAmount = (totalAmt - (((Discount.value / 100) * totalAmt))).toFixed(2);
            let calcGrandTot = ((totalAmt - (((Discount.value / 100) * totalAmt))) + totalAmt).toFixed(2);
            salesBillingForm.PercentAmount.setValue(calcPercentAmount);
            salesBillingForm.NetAmount.setValue(calcNetAmount);
            salesBillingForm.GrandAmount.setValue(calcGrandTot);
        }
        //else {
        //    alert("Entered value is greater than 100% ? " + "Your entered value is = " + Discount.value);
        //    return false;
        //}
    }
        
    validateAllFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {
                debugger
                this.validateAllFields(control);
            }
        });
    }

    //Opens confirm window modal//
    openModal2(template: TemplateRef<any>) {
        this.modalRef2 = this.modalService.show(template, { class: 'modal-sm' });
    }

    calcDiscountTotal(SalesBilling) {
        var Discount = 0;
        for (var i = 0; i < SalesBilling.length; i++) {
            Discount = Discount + parseFloat(SalesBilling[i].Discount);
        }
        return Discount;
    }

   
    calcNetAmount(SalesBilling) {
        var NetAmount = 0;
        for (var i = 0; i < SalesBilling.length; i++) {
            NetAmount = NetAmount + parseFloat(SalesBilling[i].NetAmount);
        }
        return NetAmount;
    }

    calcVATAmount(SalesBilling) {
        var VATAmount = 0;
        for (var i = 0; i < SalesBilling.length; i++) {
            VATAmount = VATAmount + parseFloat(SalesBilling[i].VATAmount);
        }
        return VATAmount;
    }

    calcGrandAmount(SalesBilling) {
        let netAmount = this.calcNetAmount(SalesBilling);
        let vatAmount = this.calcVATAmount(SalesBilling);

        let GrandAmt = netAmount + vatAmount;
        return GrandAmt;
    }

    calcAmount(SalesBilling) {
        let netAmount = this.calcNetAmount(SalesBilling);
        let AmtDicount = this.calcDiscountTotal(SalesBilling);
        let Amounta = netAmount + AmtDicount;
        return Amounta;
    }

    // Calculate sale billing Amount
    calcaAmount(netAmount: number) {
        let GrandAmt = netAmount;
        return GrandAmt;
    }

    calcaNetAmount(netAmt: number, discountAmt: number) {
        let NetAmount = netAmt - discountAmt;
        return NetAmount;
    }

    // Calculate sale billing Grand Amount
    calculateGrandAmount(vatAmount: number, netAmount: number, discountAmt: number) {
        let GrandAmt = vatAmount + (netAmount - discountAmt) ;
        return GrandAmt;
    }

    onSubmit(formData: any, fileUpload: any) {
        this.msg = "";
        this.formSubmitAttempt = true;
        let SalesBilling = this.salesBillingForm;
        if (!this.voucherDateValidator(SalesBilling.get('Date').value)) {
            return false;
        }

        SalesBilling.get('FinancialYear').setValue(this.currentYear['Name'] || '');
        SalesBilling.get('UserName').setValue(this.currentUser && this.currentUser['UserName'] || '');
        SalesBilling.get('CompanyCode').setValue(this.currentUser && this.company['BranchCode'] || '');
        debugger
        const salecontrol = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'].value;
        const salecontrols = <FormArray>this.salesBillingForm.controls['SalesOrderDetails'];
        for (var i = 0; i < salecontrol.length; i++) {
            let controlSalesOrder = this.salesBillingForm.controls.SalesOrderDetails['controls'][i].controls;
            let Id = controlSalesOrder.Id.value;

            if (Id > 0) {
                debugger
                let CurrentItemName = controlSalesOrder.ItemId.value;
                //this.MenuItem = this.MenuItemPortions.filter(x => x.Id === CurrentItemName.Name)[0];
                let CurrentItemId = CurrentItemName.Id;
                let currentinventoryItem = salecontrol[i];
                let instance = this.fb.group(currentinventoryItem);
                instance.controls["ItemId"].setValue(CurrentItemId);
                salecontrols.push(instance);
            }
            else {
                let xcurrentCurrentItemName = controlSalesOrder.ItemId.value;
                let currentinventoryItem = salecontrol[i];
                let instance = this.fb.group(currentinventoryItem);
                //this.MenuItem = this.MenuItemPortions.filter(x => x.Name === xcurrentCurrentItemName.Name)[0];
                instance.controls["ItemId"].setValue(xcurrentCurrentItemName.Id.toString());
                salecontrols.push(instance);
            }
        }
        let Id = SalesBilling.get('Id').value;
        if (Id > 0) {
            let CurrentAccount = SalesBilling.get('SourceAccountTypeId').value;
            this.currentaccount = this.CustomerAccounts.filter(x => x.Name === CurrentAccount)[0];
            if (this.currentaccount == undefined) {
                this.SourceAccountTypeId = CurrentAccount.Id;
            }
            else {
                this.SourceAccountTypeId = this.currentaccount.Id.toString();
            }
            SalesBilling.get('SourceAccountTypeId').setValue(this.SourceAccountTypeId);
        }
        else {
            let CurrentAccount = SalesBilling.get('SourceAccountTypeId').value;
            this.SourceAccountTypeId = CurrentAccount.Id;
            SalesBilling.get('SourceAccountTypeId').setValue(this.SourceAccountTypeId);
        }
        let SaleObj = {
            Id: this.salesBillingForm.controls['Id'].value,
            Date: this.salesBillingForm.controls['Date'].value,
            FinancialYear: this.salesBillingForm.controls['FinancialYear'].value,
            Name: this.salesBillingForm.controls['Name'].value,
            AccountTransactionDocumentId: this.salesBillingForm.controls['AccountTransactionDocumentId'].value,
            Description: this.salesBillingForm.controls['Description'].value,
            SourceAccountTypeId: this.salesBillingForm.controls['SourceAccountTypeId'].value,
            Amount: this.calculateAmount(),
            NetAmount: this.salesBillingForm.controls['NetAmount'].value,
            PercentAmount: this.salesBillingForm.controls['PercentAmount'].value,
            GrandAmount: this.salesBillingForm.controls['GrandAmount'].value,
            Discount: this.salesBillingForm.controls['Discount'].value,
            SalesOrderDetails: this.salesBillingForm.controls['SalesOrderDetails'].value
        }

        switch (this.dbops) {
            case DBOperation.create:
                debugger
                this._purchaseService.post(Global.BASE_SALE_BILLING_ENDPOINT, SaleObj).subscribe(
                    async (data) => {
                        if (data > 0) {
                            // file upload stuff goes here
                            await fileUpload.handleFileUpload({
                                'moduleName': 'JournalVoucher',
                                'id': data
                            });
                            this.modalRef.hide();
                            this.reset();
                            this.loadSalesBillingList(this.sfromDate, this.stoDate);
                        } else {
                            alert("There is some issue in creating records, please contact to system administrator!");
                        }
                        //this.modalRef.hide();
                        this.formSubmitAttempt = false;
                        //this.reset();
                    }
                );
                break;
            case DBOperation.update:
                this._purchaseService.put(Global.BASE_SALE_BILLING_ENDPOINT, SalesBilling.value.Id, SaleObj).subscribe(
                    async (data) => {
                        if (data > 0) {
                            // file upload stuff goes here
                            await fileUpload.handleFileUpload({
                                'moduleName': 'JournalVoucher',
                                'id': data
                            });
                            this.modalRef.hide();
                            this.reset();
                            this.loadSalesBillingList(this.sfromDate, this.stoDate);
                        } else {
                            alert("There is some issue in updating records, please contact to system administrator!");
                        }
                        //this.modalRef.hide();
                        this.formSubmitAttempt = false;
                        //this.reset();
                    },
                );
                break;
            case DBOperation.delete:
                this._purchaseService.delete(Global.BASE_SALE_BILLING_ENDPOINT, SaleObj).subscribe(
                    data => {
                        if (data == 1) {
                            alert("Data successfully deleted.");
                            this.loadSalesBillingList(this.sfromDate, this.stoDate);
                        } else {
                            alert("There is some issue in deleting records, please contact to system administrator!");
                        }
                        this.modalRef.hide();
                        this.formSubmitAttempt = false;
                        this.reset();
                    }
                );
        }
    }

    confirm(): void {
        this.modalRef2.hide();
        this.formSubmitAttempt = false;
    }

    reset() {
        this.salesBillingForm.controls['AccountTransactionDocumentId'].reset();
        this.salesBillingForm.controls['Date'].reset();
        this.salesBillingForm.controls['Discount'].reset();
        this.salesBillingForm.controls['PercentAmount'].reset();
        this.salesBillingForm.controls['NetAmount'].reset();
        this.salesBillingForm.controls['GrandAmount'].reset(); 
        this.salesBillingForm.controls['SourceAccountTypeId'].reset(); 
        this.salesBillingForm.controls['Description'].reset();
        this.salesBillingForm.controls['SalesOrderDetails'] = this.fb.array([]);
        this.addSalesBillingitems();
    }

    SetControlsState(isEnable: boolean) {
        isEnable ? this.salesBillingForm.enable() : this.salesBillingForm.disable();
    }

    onFilterDateSelect(selectedDate) {
        let currentYearStartDate = new Date(this.currentYear.StartDate);
        let currentYearEndDate = new Date(this.currentYear.EndDate);

        if (selectedDate < currentYearStartDate) {
            this.fromDate = currentYearStartDate;
            alert("Date should not be less than current financial year's start date");
        }

        if (selectedDate > currentYearEndDate) {
            this.toDate = currentYearEndDate;
            alert("Date should not be greater than current financial year's end date");
        }
    }
    nepaliDateValidator(control: FormControl) {
        let nepaliDate = control.value;
        let pattern = new RegExp(/(^[0-9]{4})\.([0-9]{2})\.([0-9]{2})/g);
        let isValid = pattern.test(nepaliDate);
        if (!isValid) {
            return {
                InvaliDate: 'The date is not valid'
            }
        }
        return null;
    }
    nepaliDateStringValidator(control: string) {
        let pattern = new RegExp(/(^[0-9]{4})\.([0-9]{2})\.([0-9]{2})/g);
        let isValid = pattern.test(control);
        if (!isValid) {
            return false;
        }
        else {
            return true;
        }
    }
    // Calculate Purchase Amount
    calculateSaleAmount(SalesOrderDetails: any) {
        return SalesOrderDetails.TotalAmount.setValue(SalesOrderDetails.Qty.value * SalesOrderDetails.UnitPrice.value);
    }
    searchChange($event) {
        console.log($event);
    }
    config = {
        displayKey: 'Name', // if objects array passed which key to be displayed defaults to description
        search: true,
        limitTo: 1000
    };
    searchChangeItem($event) {
        console.log($event);
    }
    configItem = {
        displayKey: 'Name', // if objects array passed which key to be displayed defaults to description
        search: true,
        limitTo: 1000
    };
}
