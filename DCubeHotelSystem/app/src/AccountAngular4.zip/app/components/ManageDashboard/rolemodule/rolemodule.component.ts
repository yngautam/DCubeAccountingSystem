﻿import { Component } from '@angular/core';

@Component({
    templateUrl: './rolemodule.component.html'
})
export class RoleModuleComponent {
  
}
