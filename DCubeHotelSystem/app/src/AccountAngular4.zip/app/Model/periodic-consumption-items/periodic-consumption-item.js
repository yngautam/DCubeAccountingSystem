"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PeriodicConsumption = /** @class */ (function () {
    function PeriodicConsumption() {
    }
    return PeriodicConsumption;
}());
exports.PeriodicConsumption = PeriodicConsumption;
var PeriodicConsumptionItem = /** @class */ (function () {
    function PeriodicConsumptionItem() {
    }
    return PeriodicConsumptionItem;
}());
exports.PeriodicConsumptionItem = PeriodicConsumptionItem;
