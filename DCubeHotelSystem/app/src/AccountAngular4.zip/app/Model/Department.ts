﻿export interface IDepartment {
    Id: number,
    Name: string

}