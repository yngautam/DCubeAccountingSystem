"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ICategory = /** @class */ (function () {
    function ICategory() {
    }
    return ICategory;
}());
exports.ICategory = ICategory;
var InventoryItem = /** @class */ (function () {
    function InventoryItem(Name) {
        this.Name = Name;
    }
    return InventoryItem;
}());
exports.InventoryItem = InventoryItem;
