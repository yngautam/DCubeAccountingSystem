"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ViewInventoryItem = /** @class */ (function () {
    function ViewInventoryItem() {
    }
    return ViewInventoryItem;
}());
exports.ViewInventoryItem = ViewInventoryItem;
