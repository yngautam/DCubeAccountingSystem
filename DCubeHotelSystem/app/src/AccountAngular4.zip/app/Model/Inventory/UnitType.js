"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UnitType = /** @class */ (function () {
    function UnitType() {
    }
    return UnitType;
}());
exports.UnitType = UnitType;
