﻿export class ViewInventoryItem {
    Id: number;
    Qty: number;
    CategoryName: string;
    Name: string;
    UnitType: string;
}
