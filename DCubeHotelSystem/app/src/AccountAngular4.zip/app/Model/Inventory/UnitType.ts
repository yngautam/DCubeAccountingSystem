﻿export class UnitType {
    Id: number;
    Name?: string;
}