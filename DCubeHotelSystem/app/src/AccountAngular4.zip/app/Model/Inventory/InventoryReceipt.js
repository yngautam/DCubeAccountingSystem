"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var InventoryReceipt = /** @class */ (function () {
    function InventoryReceipt() {
    }
    return InventoryReceipt;
}());
exports.InventoryReceipt = InventoryReceipt;
var InventoryReceiptDetails = /** @class */ (function () {
    function InventoryReceiptDetails() {
    }
    return InventoryReceiptDetails;
}());
exports.InventoryReceiptDetails = InventoryReceiptDetails;
