"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountTrans = /** @class */ (function () {
    function AccountTrans() {
    }
    return AccountTrans;
}());
exports.AccountTrans = AccountTrans;
var AccountTransactionValues = /** @class */ (function () {
    function AccountTransactionValues() {
    }
    return AccountTransactionValues;
}());
exports.AccountTransactionValues = AccountTransactionValues;
var InventoryReceiptDetail = /** @class */ (function () {
    function InventoryReceiptDetail() {
    }
    return InventoryReceiptDetail;
}());
exports.InventoryReceiptDetail = InventoryReceiptDetail;
var PurchaseOrderDetail = /** @class */ (function () {
    function PurchaseOrderDetail() {
    }
    return PurchaseOrderDetail;
}());
exports.PurchaseOrderDetail = PurchaseOrderDetail;
var PurchaseDetail = /** @class */ (function () {
    function PurchaseDetail() {
    }
    return PurchaseDetail;
}());
exports.PurchaseDetail = PurchaseDetail;
var ScreenOrderDetail = /** @class */ (function () {
    function ScreenOrderDetail() {
    }
    return ScreenOrderDetail;
}());
exports.ScreenOrderDetail = ScreenOrderDetail;
var EntityMock = /** @class */ (function () {
    function EntityMock() {
    }
    return EntityMock;
}());
exports.EntityMock = EntityMock;
