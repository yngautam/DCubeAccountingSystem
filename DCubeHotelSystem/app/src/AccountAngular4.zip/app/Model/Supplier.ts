﻿export interface ISupplier {
    Id: number,
    Name: string
}