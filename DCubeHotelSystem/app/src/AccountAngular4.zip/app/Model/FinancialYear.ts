﻿export interface IFinancialYear {
    Id?: number;
	Name?: string;
	NepaliEndDate?: string;	
	NepaliStartDate?: string;
    StartDate?: string;
    EndDate?: string;
}
