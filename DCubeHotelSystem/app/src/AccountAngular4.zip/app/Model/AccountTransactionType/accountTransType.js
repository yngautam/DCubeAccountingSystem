"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountTransType = /** @class */ (function () {
    function AccountTransType() {
    }
    return AccountTransType;
}());
exports.AccountTransType = AccountTransType;
