﻿export interface NepaliMonth {
    Name: string;
}