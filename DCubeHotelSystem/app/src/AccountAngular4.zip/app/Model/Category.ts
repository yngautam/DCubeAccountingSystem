﻿export interface ICategory{
    Id: number,
    Name: string
}