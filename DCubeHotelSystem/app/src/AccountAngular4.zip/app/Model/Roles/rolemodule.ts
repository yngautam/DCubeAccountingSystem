﻿export class RoleModule {
    Id: number;
    RoleId: number;
    ModuleId: number;
    ParentModuleId: number;
}