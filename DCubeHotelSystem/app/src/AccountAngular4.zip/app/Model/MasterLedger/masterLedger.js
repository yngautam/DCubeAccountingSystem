"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MasterLedger = /** @class */ (function () {
    function MasterLedger(Name) {
        this.Name = Name;
    }
    return MasterLedger;
}());
exports.MasterLedger = MasterLedger;
