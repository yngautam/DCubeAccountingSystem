﻿export interface ProfitAndLoss {
    Id: number,
    Name: string,
    Amount: number,
    NatureofGroup: string,
    SortOrder: number,
    Bold:string
}