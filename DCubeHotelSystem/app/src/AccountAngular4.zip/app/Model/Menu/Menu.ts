﻿export interface IMenu {
    Id: number,
    Name: string
    //MenuItem: string,
    //Categories: string
}