"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IScreenMenuCategorys = /** @class */ (function () {
    function IScreenMenuCategorys(categoryId, MenuId, Menu_Bool) {
        this.categoryId = categoryId;
        this.MenuId = MenuId;
        this.Menu_Bool = Menu_Bool;
    }
    return IScreenMenuCategorys;
}());
exports.IScreenMenuCategorys = IScreenMenuCategorys;
