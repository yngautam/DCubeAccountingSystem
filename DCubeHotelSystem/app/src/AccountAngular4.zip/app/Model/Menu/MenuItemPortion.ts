﻿export interface MenuItemPortion {
    Id: number;
    MenuItemPortionId: number;
    Multiplier: number;
    Name: string;
    Price: number
}