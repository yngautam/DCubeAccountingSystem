﻿export interface ITable {
    Id: number,
    name: string
}