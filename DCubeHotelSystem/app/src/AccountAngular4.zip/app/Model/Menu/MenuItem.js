"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IScreenMenuItems = /** @class */ (function () {
    function IScreenMenuItems(ItemId, categoryId, MenuId, MenuItem_Bool) {
        this.ItemId = ItemId;
        this.categoryId = categoryId;
        this.MenuId = MenuId;
        this.MenuItem_Bool = MenuItem_Bool;
    }
    return IScreenMenuItems;
}());
exports.IScreenMenuItems = IScreenMenuItems;
