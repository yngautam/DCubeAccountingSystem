﻿export interface LedgerView {
    Id: number,
    VDate:string,
    Name: string,
    VType: string,
    VNumber:string,
    Debit: number,
    Credit: number
}