"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountType = /** @class */ (function () {
    function AccountType() {
    }
    return AccountType;
}());
exports.AccountType = AccountType;
