﻿export interface TrialBalance {
    Id: number,
    Name: string,
    Debit: number,
    Credit: number
}