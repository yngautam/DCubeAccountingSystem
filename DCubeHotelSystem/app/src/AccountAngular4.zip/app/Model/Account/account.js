"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Account = /** @class */ (function () {
    function Account(Name) {
        this.Name = Name;
    }
    return Account;
}());
exports.Account = Account;
