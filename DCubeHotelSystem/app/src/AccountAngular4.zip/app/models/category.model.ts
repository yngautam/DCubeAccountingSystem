﻿/**	
 * Defines the model for category entity
 */
export interface Category {
	Id: number;
	Name: string;
}