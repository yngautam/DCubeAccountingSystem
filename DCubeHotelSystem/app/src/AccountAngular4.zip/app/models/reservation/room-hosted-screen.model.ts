/**	
 * Defines the model for Room HostedScreen entity
 */
export interface RoomHostedScreen {
	Id: number;
	CustomerName: string;
}