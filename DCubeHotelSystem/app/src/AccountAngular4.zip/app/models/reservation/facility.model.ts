/**	
 * Defines the model for facility entity
 */
export interface Facility {
	Id: number;
	Name: string;
}