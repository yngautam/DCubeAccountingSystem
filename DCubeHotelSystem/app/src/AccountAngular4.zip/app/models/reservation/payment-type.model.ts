/**	
 * Defines the model for Payment Type entity
 */
export interface PaymentType {
	Id: number;
	Name: string;
}