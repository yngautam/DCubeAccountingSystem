/**	
 * Defines the model for Reservation Detail Entity
 */
export interface ReservationDetail {
	Id: number,
    ReservationId: boolean,
    ChildernAge: string
}
