/**	
 * Defines the model for Reservation entity
 */
export interface CustomerType {
	Id: number;
	Name: string;
}