/**	
 * Defines the model for Room Hosted entity
 */
export interface RoomHosted {
	Id: number;
	CustomerId: number;
	RoomOccupiedId: number;
}