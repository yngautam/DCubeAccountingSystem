/**	
 * Defines the model for Room Type entity
 */
export interface RoomType {
	Id: number;
	Name: string;
}