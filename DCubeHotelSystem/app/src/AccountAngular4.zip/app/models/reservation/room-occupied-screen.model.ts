/**	
 * Defines the model for Room OccupiedScreen entity
 */
export interface RoomOccupiedScreen {
	Id: number;
	RoomNumber: number;
	CheckIn: Date;
	CheckOut: Date;
}