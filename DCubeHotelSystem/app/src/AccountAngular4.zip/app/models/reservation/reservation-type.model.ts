/**	
 * Defines the model for Reservation Type entity
 */
export interface ReservationType {
	Id: number;
	Name: string;
}