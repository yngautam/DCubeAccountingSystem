/**	
 * Defines the model for Room Reserved Screen entity
 */
export interface RoomReservedScreen {
	Id: number;
	NumberofRoom: string;
	RoomTypeName: string;
	status: string;
}
