/**	
 * Defines the model for Room Occupied entity
 */
export interface RoomOccupied {
	Id: number;
	CustomerId: number;
	ReservationId: number;
	listRoomOccupiedDetail: any[]
}
