"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CustomerType = /** @class */ (function () {
    function CustomerType() {
    }
    return CustomerType;
}());
exports.CustomerType = CustomerType;
