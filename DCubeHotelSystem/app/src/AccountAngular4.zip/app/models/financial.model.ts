/**	
 * Defines the model for Financial entity
 */
export interface Financial {
	Id?: number;
	Name?: string;
	NepaliEndDate?: string;	
	NepaliStartDate?: string;
    StartDate?: string;
    EndDate?: string;
}
